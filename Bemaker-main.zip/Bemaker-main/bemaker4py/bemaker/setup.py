from setuptools import setup

setup(name='bemaker',
        version='0.0.1',
        install_requires=['numpy', 'gym >= 0.26.2'],
        py_modules=[]
)
