using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace bemaker
{
    public class ControlConfiguration : MonoBehaviour
    {
        public int skipFrame = 4;
        public bool repeatAction = true;
    }
}
