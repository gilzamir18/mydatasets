using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace bemaker {
    public class ActionReward: RewardFunc
    {
        public virtual void RewardFrom(string actionName, BasicAgent agent) {
            
        }
    }
}
