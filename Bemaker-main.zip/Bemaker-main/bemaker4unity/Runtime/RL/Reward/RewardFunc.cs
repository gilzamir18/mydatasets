﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using bemaker;

namespace bemaker {
    public class RewardFunc : MonoBehaviour, IAgentResetListener
    {
        public bool causeEpisodeToEnd = false;
        
        public virtual void OnSetup(Agent agent)
        {

        }

        public virtual void OnUpdate()
        {

        }

        public virtual void OnReset(Agent agent) {

        }
    }
}